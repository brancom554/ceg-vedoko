<div id="gp-fixed-header-padding"></div>
<div class="gp-clear"></div>
<div id="gp-page-wrapper">
    <header id="gp-page-title" class="gp-container">
        <div class="gp-container">
            <div id="gp-breadcrumbs" class="gp-active"><span><span><a href="<?= base_url() ?>">Home</a>  » <span class="breadcrumb_last" aria-current="page">About</span></span>
                    </span>
                </span>
            </div>
            <div id="gp-page-title-text">
                <h1> About</h1>
            </div>
        </div>
        <div class="gp-clear"></div>
    </header>
    <br>
    <div id="gp-content-wrapper" class="gp-container">
        <div id="gp-inner-container">
            <div id="gp-content">
                <div class="gp-entry-content">
                    <div class="vc_row wpb_row vc_row-fluid">
                        <div class="wpb_column vc_column_container vc_col-sm-12">
                            <div class="vc_column-inner ">
                                <div class="wpb_wrapper">
                                    <div id="gp_showcase_wrapper_1" class="gp-showcase-wrapper gp-ajax-element gp-posts-horizontal gp-style-classic gp-align-left gp-no-ranking" data-type="showcase" data-currentpostid="318" data-posttypes="post" data-format="gp-posts-horizontal" data-style="gp-style-classic" data-orderby="newest" data-perpage="5" data-pagination="disabled" data-pagearrows="disabled" data-ranking="gp-no-ranking" data-largeexcerptlength="220" data-largereadmorelink="disabled" data-smallreadmorelink="disabled">
                                        <div class="gp-widget-title"></div>
                                        <div class="gp-section-loop gp-ajax-loop">
                                            <div class="gp-section-loop-inner">
                                                <div class="gp-large-post">
                                                    <section class="gp-post-item post-378 post type-post status-publish format-standard has-post-thumbnail category-news tag-article tag-blog tag-theme tag-themeforest tag-wordpress pmpro-has-access">
                                                        <div class="gp-post-thumbnail gp-loop-featured">
                                                            <a href="../../news/objectively-incubate-strategic-growth/index.html" title="Objectively incubate strategic growth"> <img width="727" height="393" src="../../wp-content/uploads/sites/6/2017/11/elephant-1822636_1280-727x393.jpg" class="attachment-gp_column_image size-gp_column_image wp-post-image" alt="" loading="lazy" srcset="https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/elephant-1822636_1280-727x393.jpg 727w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/elephant-1822636_1280-250x135.jpg 250w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/elephant-1822636_1280-864x467.jpg 864w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/elephant-1822636_1280-414x224.jpg 414w" sizes="(max-width: 727px) 100vw, 727px" /> </a>
                                                        </div>
                                                        <div class="gp-loop-content">
                                                            <h2 class="gp-loop-title"><a href="../../news/objectively-incubate-strategic-growth/index.html" title="Objectively incubate strategic growth">Objectively incubate strategic growth</a></h2>
                                                            <div class="gp-loop-text">
                                                                <p>Intrinsicly engineer alternative ideas after orthogonal e-business. Credibly strategize optimal imperatives without innovative imperatives. Rapidiously customize accurate human capital after bricks-and-clicks benefits. C...</p>
                                                            </div>
                                                        </div>
                                                    </section>
                                                </div>
                                                <div class="gp-small-posts">
                                                    <section class="gp-post-item post-376 post type-post status-publish format-standard has-post-thumbnail category-news tag-article tag-blog tag-theme tag-themeforest tag-wordpress pmpro-has-access">
                                                        <div class="gp-post-thumbnail gp-loop-featured">
                                                            <a href="../../news/completely-strategize-client-based-niche/index.html" title="Completely strategize client-based niche"> <img width="75" height="75" src="../../wp-content/uploads/sites/6/2017/11/photodune-2359890-elegant-hairstyle-s-75x75.jpg" class="attachment-gp_small_image size-gp_small_image wp-post-image" alt="" loading="lazy" srcset="https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/photodune-2359890-elegant-hairstyle-s-75x75.jpg 75w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/photodune-2359890-elegant-hairstyle-s-150x150.jpg 150w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/photodune-2359890-elegant-hairstyle-s-100x100.jpg 100w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/photodune-2359890-elegant-hairstyle-s-300x300.jpg 300w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/photodune-2359890-elegant-hairstyle-s-180x180.jpg 180w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/photodune-2359890-elegant-hairstyle-s-600x600.jpg 600w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/photodune-2359890-elegant-hairstyle-s-110x110.jpg 110w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/photodune-2359890-elegant-hairstyle-s-116x116.jpg 116w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/photodune-2359890-elegant-hairstyle-s-117x117.jpg 117w" sizes="(max-width: 75px) 100vw, 75px" /> </a>
                                                        </div>
                                                        <div class="gp-loop-content">
                                                            <h2 class="gp-loop-title"><a href="../../news/completely-strategize-client-based-niche/index.html" title="Completely strategize client-based niche">Completely strategize client-based niche</a></h2>
                                                        </div>
                                                    </section>
                                                    <section class="gp-post-item post-390 post type-post status-publish format-standard has-post-thumbnail category-news tag-article tag-blog tag-theme tag-themeforest tag-wordpress pmpro-has-access">
                                                        <div class="gp-post-thumbnail gp-loop-featured">
                                                            <a href="../../news/intrinsicly-streamline-go-forward-internal/index.html" title="Intrinsicly streamline go forward internal"> <img width="75" height="75" src="../../wp-content/uploads/sites/6/2017/11/mystery-1599527_1920-75x75.jpg" class="attachment-gp_small_image size-gp_small_image wp-post-image" alt="" loading="lazy" srcset="https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/mystery-1599527_1920-75x75.jpg 75w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/mystery-1599527_1920-150x150.jpg 150w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/mystery-1599527_1920-100x100.jpg 100w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/mystery-1599527_1920-300x300.jpg 300w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/mystery-1599527_1920-180x180.jpg 180w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/mystery-1599527_1920-600x600.jpg 600w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/mystery-1599527_1920-110x110.jpg 110w" sizes="(max-width: 75px) 100vw, 75px" /> </a>
                                                        </div>
                                                        <div class="gp-loop-content">
                                                            <h2 class="gp-loop-title"><a href="../../news/intrinsicly-streamline-go-forward-internal/index.html" title="Intrinsicly streamline go forward internal">Intrinsicly streamline go forward internal</a></h2>
                                                        </div>
                                                    </section>
                                                    <section class="gp-post-item post-109 post type-post status-publish format-standard has-post-thumbnail category-news tag-article tag-blog tag-theme tag-themeforest tag-wordpress pmpro-has-access">
                                                        <div class="gp-post-thumbnail gp-loop-featured">
                                                            <a href="../../news/enthusiastically-revolutionize-backend/index.html" title="Enthusiastically revolutionize backend"> <img width="75" height="75" src="../../wp-content/uploads/sites/6/2017/11/green-hair-women-75x75.jpg" class="attachment-gp_small_image size-gp_small_image wp-post-image" alt="" loading="lazy" srcset="https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/green-hair-women-75x75.jpg 75w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/green-hair-women-150x150.png 150w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/green-hair-women-100x100.jpg 100w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/green-hair-women-300x300.png 300w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/green-hair-women-180x180.jpg 180w" sizes="(max-width: 75px) 100vw, 75px" /> </a>
                                                        </div>
                                                        <div class="gp-loop-content">
                                                            <h2 class="gp-loop-title"><a href="../../news/enthusiastically-revolutionize-backend/index.html" title="Enthusiastically revolutionize backend">Enthusiastically revolutionize backend</a></h2>
                                                        </div>
                                                    </section>
                                                    <section class="gp-post-item post-107 post type-post status-publish format-standard has-post-thumbnail category-news tag-article tag-blog tag-theme tag-themeforest tag-wordpress pmpro-has-access">
                                                        <div class="gp-post-thumbnail gp-loop-featured">
                                                            <a href="../../news/conveniently-provide-access-to-professional-methods/index.html" title="Conveniently provide access to professional methods"> <img width="75" height="75" src="../../wp-content/uploads/sites/6/2017/11/women-with-balls-75x75.jpg" class="attachment-gp_small_image size-gp_small_image wp-post-image" alt="" loading="lazy" srcset="https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/women-with-balls-75x75.jpg 75w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/women-with-balls-150x150.jpg 150w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/women-with-balls-100x100.jpg 100w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/women-with-balls-300x300.jpg 300w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/women-with-balls-180x180.jpg 180w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/women-with-balls-600x600.jpg 600w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/women-with-balls-110x110.jpg 110w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/women-with-balls-116x116.jpg 116w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/women-with-balls-117x117.jpg 117w" sizes="(max-width: 75px) 100vw, 75px" /> </a>
                                                        </div>
                                                        <div class="gp-loop-content">
                                                            <h2 class="gp-loop-title"><a href="../../news/conveniently-provide-access-to-professional-methods/index.html" title="Conveniently provide access to professional methods">Conveniently provide access to professional methods</a></h2>
                                                        </div>
                                                    </section>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="vc_empty_space" style="height: 32px"><span class="vc_empty_space_inner"></span></div>
                                    <div class="vc_row wpb_row vc_inner vc_row-fluid">
                                        <div class="wpb_column vc_column_container vc_col-sm-6">
                                            <div class="vc_column-inner">
                                                <div class="wpb_wrapper">
                                                    <div id="gp_showcase_wrapper_2" class="gp-showcase-wrapper gp-ajax-element gp-posts-vertical gp-style-classic gp-align-left gp-no-ranking" data-type="showcase" data-currentpostid="318" data-posttypes="post" data-format="gp-posts-vertical" data-style="gp-style-classic" data-orderby="newest" data-perpage="5" data-pagination="disabled" data-pagearrows="disabled" data-ranking="gp-no-ranking" data-largeexcerptlength="80" data-largereadmorelink="disabled" data-smallreadmorelink="disabled">
                                                        <div class="gp-widget-title"></div>
                                                        <div class="gp-section-loop gp-ajax-loop">
                                                            <div class="gp-section-loop-inner">
                                                                <div class="gp-large-post">
                                                                    <section class="gp-post-item post-378 post type-post status-publish format-standard has-post-thumbnail category-news tag-article tag-blog tag-theme tag-themeforest tag-wordpress pmpro-has-access">
                                                                        <div class="gp-post-thumbnail gp-loop-featured">
                                                                            <a href="../../news/objectively-incubate-strategic-growth/index.html" title="Objectively incubate strategic growth"> <img width="727" height="393" src="../../wp-content/uploads/sites/6/2017/11/elephant-1822636_1280-727x393.jpg" class="attachment-gp_column_image size-gp_column_image wp-post-image" alt="" loading="lazy" srcset="https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/elephant-1822636_1280-727x393.jpg 727w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/elephant-1822636_1280-250x135.jpg 250w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/elephant-1822636_1280-864x467.jpg 864w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/elephant-1822636_1280-414x224.jpg 414w" sizes="(max-width: 727px) 100vw, 727px" /> </a>
                                                                        </div>
                                                                        <div class="gp-loop-content">
                                                                            <h2 class="gp-loop-title"><a href="../../news/objectively-incubate-strategic-growth/index.html" title="Objectively incubate strategic growth">Objectively incubate strategic growth</a></h2>
                                                                            <div class="gp-loop-text">
                                                                                <p>Intrinsicly engineer alternative ideas after orthogonal e-business. Credibly str...</p>
                                                                            </div>
                                                                        </div>
                                                                    </section>
                                                                </div>
                                                                <div class="gp-small-posts">
                                                                    <section class="gp-post-item post-376 post type-post status-publish format-standard has-post-thumbnail category-news tag-article tag-blog tag-theme tag-themeforest tag-wordpress pmpro-has-access">
                                                                        <div class="gp-post-thumbnail gp-loop-featured">
                                                                            <a href="../../news/completely-strategize-client-based-niche/index.html" title="Completely strategize client-based niche"> <img width="75" height="75" src="../../wp-content/uploads/sites/6/2017/11/photodune-2359890-elegant-hairstyle-s-75x75.jpg" class="attachment-gp_small_image size-gp_small_image wp-post-image" alt="" loading="lazy" srcset="https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/photodune-2359890-elegant-hairstyle-s-75x75.jpg 75w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/photodune-2359890-elegant-hairstyle-s-150x150.jpg 150w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/photodune-2359890-elegant-hairstyle-s-100x100.jpg 100w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/photodune-2359890-elegant-hairstyle-s-300x300.jpg 300w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/photodune-2359890-elegant-hairstyle-s-180x180.jpg 180w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/photodune-2359890-elegant-hairstyle-s-600x600.jpg 600w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/photodune-2359890-elegant-hairstyle-s-110x110.jpg 110w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/photodune-2359890-elegant-hairstyle-s-116x116.jpg 116w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/photodune-2359890-elegant-hairstyle-s-117x117.jpg 117w" sizes="(max-width: 75px) 100vw, 75px" /> </a>
                                                                        </div>
                                                                        <div class="gp-loop-content">
                                                                            <h2 class="gp-loop-title"><a href="../../news/completely-strategize-client-based-niche/index.html" title="Completely strategize client-based niche">Completely strategize client-based niche</a></h2>
                                                                        </div>
                                                                    </section>
                                                                    <section class="gp-post-item post-390 post type-post status-publish format-standard has-post-thumbnail category-news tag-article tag-blog tag-theme tag-themeforest tag-wordpress pmpro-has-access">
                                                                        <div class="gp-post-thumbnail gp-loop-featured">
                                                                            <a href="../../news/intrinsicly-streamline-go-forward-internal/index.html" title="Intrinsicly streamline go forward internal"> <img width="75" height="75" src="../../wp-content/uploads/sites/6/2017/11/mystery-1599527_1920-75x75.jpg" class="attachment-gp_small_image size-gp_small_image wp-post-image" alt="" loading="lazy" srcset="https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/mystery-1599527_1920-75x75.jpg 75w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/mystery-1599527_1920-150x150.jpg 150w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/mystery-1599527_1920-100x100.jpg 100w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/mystery-1599527_1920-300x300.jpg 300w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/mystery-1599527_1920-180x180.jpg 180w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/mystery-1599527_1920-600x600.jpg 600w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/mystery-1599527_1920-110x110.jpg 110w" sizes="(max-width: 75px) 100vw, 75px" /> </a>
                                                                        </div>
                                                                        <div class="gp-loop-content">
                                                                            <h2 class="gp-loop-title"><a href="../../news/intrinsicly-streamline-go-forward-internal/index.html" title="Intrinsicly streamline go forward internal">Intrinsicly streamline go forward internal</a></h2>
                                                                        </div>
                                                                    </section>
                                                                    <section class="gp-post-item post-109 post type-post status-publish format-standard has-post-thumbnail category-news tag-article tag-blog tag-theme tag-themeforest tag-wordpress pmpro-has-access">
                                                                        <div class="gp-post-thumbnail gp-loop-featured">
                                                                            <a href="../../news/enthusiastically-revolutionize-backend/index.html" title="Enthusiastically revolutionize backend"> <img width="75" height="75" src="../../wp-content/uploads/sites/6/2017/11/green-hair-women-75x75.jpg" class="attachment-gp_small_image size-gp_small_image wp-post-image" alt="" loading="lazy" srcset="https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/green-hair-women-75x75.jpg 75w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/green-hair-women-150x150.png 150w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/green-hair-women-100x100.jpg 100w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/green-hair-women-300x300.png 300w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/green-hair-women-180x180.jpg 180w" sizes="(max-width: 75px) 100vw, 75px" /> </a>
                                                                        </div>
                                                                        <div class="gp-loop-content">
                                                                            <h2 class="gp-loop-title"><a href="../../news/enthusiastically-revolutionize-backend/index.html" title="Enthusiastically revolutionize backend">Enthusiastically revolutionize backend</a></h2>
                                                                        </div>
                                                                    </section>
                                                                    <section class="gp-post-item post-107 post type-post status-publish format-standard has-post-thumbnail category-news tag-article tag-blog tag-theme tag-themeforest tag-wordpress pmpro-has-access">
                                                                        <div class="gp-post-thumbnail gp-loop-featured">
                                                                            <a href="../../news/conveniently-provide-access-to-professional-methods/index.html" title="Conveniently provide access to professional methods"> <img width="75" height="75" src="../../wp-content/uploads/sites/6/2017/11/women-with-balls-75x75.jpg" class="attachment-gp_small_image size-gp_small_image wp-post-image" alt="" loading="lazy" srcset="https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/women-with-balls-75x75.jpg 75w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/women-with-balls-150x150.jpg 150w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/women-with-balls-100x100.jpg 100w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/women-with-balls-300x300.jpg 300w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/women-with-balls-180x180.jpg 180w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/women-with-balls-600x600.jpg 600w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/women-with-balls-110x110.jpg 110w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/women-with-balls-116x116.jpg 116w, https://aardvark.ghostpool.com/original/wp-content/uploads/sites/6/2017/11/women-with-balls-117x117.jpg 117w" sizes="(max-width: 75px) 100vw, 75px" /> </a>
                                                                        </div>
                                                                        <div class="gp-loop-content">
                                                                            <h2 class="gp-loop-title"><a href="../../news/conveniently-provide-access-to-professional-methods/index.html" title="Conveniently provide access to professional methods">Conveniently provide access to professional methods</a></h2>
                                                                        </div>
                                                                    </section>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="gp-clear"></div>
    </div>
    <div class="gp-clear"></div>
</div>