<div id="gp-fixed-header-padding"></div>
<div class="gp-clear"></div>
<div id="gp-page-wrapper">
    <div id="gp-content-wrapper" class="gp-container">
        <div id="gp-inner-container">
            <div id="gp-content">
                <div data-vc-full-width="true" data-vc-full-width-init="false" class="vc_row wpb_row vc_row-fluid wpb_animate_when_almost_visible wpb_fadeIn fadeIn vc_custom_1581675387899 vc_row-has-fill vc_row-o-equal-height vc_row-flex gp-scrolling-image bb_custom_1581675387908 bb_custom_1581675387909">
                    <div class="gp-animated-gradient-column">
                        <div class="wpb_column vc_column_container vc_col-sm-12 vc_col-has-fill bb_custom_1581675377234 bb_custom_1581675377237 bb_custom_1581675377238" style="background-position: right center !important;">
                            <div class="vc_column-inner vc_custom_1581675377231" style="background-position: right center !important;">
                                <div class="wpb_wrapper">
                                    <div style="font-size: 40px;color: #ffffff;line-height: 40px;text-align: left;font-family:Roboto;font-weight:500;font-style:normal" class="vc_custom_heading bb_custom_1514733568153">Welcome</div>
                                    <div style="font-size: 50px;color: #39c8df;line-height: 50px;text-align: left;font-family:Roboto;font-weight:300;font-style:normal" class="vc_custom_heading bb_custom_1514739151193 bb_custom_1514739150370">Join the community</div>
                                    <p style="font-size: 20px;color: #ffffff;line-height: 30px;text-align: left" class="vc_custom_heading fa-circle-o gp-green bb_custom_1514733595433">Over a hundred thousand members</p>
                                    <p style="font-size: 20px;color: #ffffff;line-height: 30px;text-align: left" class="vc_custom_heading fa-circle-o gp-green bb_custom_1514733602893">Access to thousands of groups</p>
                                    <p style="font-size: 20px;color: #ffffff;line-height: 30px;text-align: left" class="vc_custom_heading fa-circle-o gp-green bb_custom_1514733609890">Premium content</p>
                                    <p style="font-size: 20px;color: #ffffff;line-height: 30px;text-align: left" class="vc_custom_heading fa-circle-o gp-green bb_custom_1514733622591">30 day money-back guarantee</p>
                                    <style type="text/css">
                                        .vc_btn3-style-gradient-custom.vc_btn-gradient-btn-615c16759b005:hover {
                                            color: #ffffff;
                                            background-color: #39c8df;
                                            border: none;
                                            background-position: 100% 0;
                                        }
                                    </style>
                                    <style type="text/css">
                                        .vc_btn3-style-gradient-custom.vc_btn-gradient-btn-615c16759b005 {
                                            color: #ffffff;
                                            border: none;
                                            background-color: #00a0e3;
                                            background-image: -webkit-linear-gradient(left, #00a0e3 0%, #39c8df 50%, #00a0e3 100%);
                                            background-image: linear-gradient(to right, #00a0e3 0%, #39c8df 50%, #00a0e3 100%);
                                            -webkit-transition: all .2s ease-in-out;
                                            transition: all .2s ease-in-out;
                                            background-size: 200% 100%;
                                        }
                                    </style>
                                    <div class="vc_btn3-container  gp-scroll-to-link vc_btn3-left vc_custom_1514738540819 bb_custom_1514738540245 bb_custom_1514738540246"> <a data-vc-gradient-1="#00a0e3" data-vc-gradient-2="#39c8df" class="vc_general vc_btn3 vc_btn3-size-lg vc_btn3-shape-rounded vc_btn3-style-gradient-custom vc_btn-gradient-btn-615c16759b005 bb_custom_1514738540245 bb_custom_1514738540246" href="#membership-levels" title="">Sign up from $9/month</a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="gp-animated-gradient-bg" style="background: -moz-linear-gradient(45deg, rgba(0,0,0,1) 0%, rgba(0,0,0,0.82) 41%, rgba(54,149,156,0.47) 67%, rgba(0,220,255,0.36) 75%, rgba(195,195,195,0.6) 100%);background: -webkit-linear-gradient(45deg, rgba(0,0,0,1) 0%,rgba(0,0,0,0.82) 41%,rgba(54,149,156,0.47) 67%,rgba(0,220,255,0.36) 75%,rgba(195,195,195,0.6) 100%);background: linear-gradient(45deg, rgba(0,0,0,1) 0%,rgba(0,0,0,0.82) 41%,rgba(54,149,156,0.47) 67%,rgba(0,220,255,0.36) 75%,rgba(195,195,195,0.6) 100%);"></div>
                </div>
                <div class="vc_row-full-width vc_clearfix"></div>
                <!-- <div id="membership-levels" data-vc-full-width="true" data-vc-full-width-init="false" class="vc_row wpb_row vc_row-fluid vc_custom_1511099472798 vc_row-has-fill">
                    <div class="wpb_column vc_column_container vc_col-sm-12">
                        <div class="vc_column-inner vc_custom_1506677824556">
                            <div class="wpb_wrapper">
                                <div style="font-size: 36px;color: #232323;line-height: 36px;text-align: center;font-family:Roboto;font-weight:700;font-style:normal" class="vc_custom_heading vc_custom_1509111819249 bb_custom_1509111811435">Membership Levels</div>
                                <div style="color: #999999;text-align: center" class="vc_custom_heading vc_custom_1506678632758 bb_custom_1506678632759 bb_custom_1506678632761">Set up unlimited membership levels, whether they are free, paid, or recurring subscriptions. Offer trial periods and discount pricing.</div>
                                <div class="vc_row wpb_row vc_inner vc_row-fluid vc_row-o-equal-height vc_row-o-content-top vc_row-flex">
                                    <div class="wpb_column vc_column_container vc_col-sm-4 bb_custom_1506681078934">
                                        <div class="vc_column-inner">
                                            <div class="wpb_wrapper">
                                                <div id="gp_pricing_column_1" class="gp-pricing-column gp-normal-column gp-style-1">
                                                    <div class="gp-pricing-column-header">
                                                        <h5 class="gp-pricing-column-title"> Bronze</h5>
                                                    </div>
                                                    <div class="gp-pricing-column-costs">
                                                        <div class="gp-pricing-column-circle">
                                                            <h5 class="gp-pricing-column-symbol">$</h5>
                                                            <h5 class="gp-pricing-column-price">9</h5>
                                                            <h6 class="gp-pricing-column-interval">per month</h6>
                                                        </div>
                                                    </div>
                                                    <div class="gp-pricing-column-divider"></div>
                                                    <div class="gp-pricing-column-content">
                                                        <ul>
                                                            <li>View members directory</li>
                                                            <li>View member profiles</li>
                                                            <li>Access to groups directory</li>
                                                            <li>Access to groups</li>
                                                            <li>View site activity</li>
                                                            <li>Send private messages</li>
                                                        </ul>
                                                    </div>
                                                    <div class="gp-pricing-column-divider"></div>
                                                    <div class="gp-pricing-column-footer"> <a href="membership-account/membership-checkout/index7e60.html?level=1" class="gp-pricing-column-button">Sign Up</a></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="wpb_column vc_column_container vc_col-sm-4 bb_custom_1506681084964">
                                        <div class="vc_column-inner">
                                            <div class="wpb_wrapper">
                                                <div id="gp_pricing_column_2" class="gp-pricing-column gp-normal-column gp-style-1">
                                                    <div class="gp-pricing-column-header">
                                                        <h5 class="gp-pricing-column-title"> Silver</h5>
                                                    </div>
                                                    <div class="gp-pricing-column-costs">
                                                        <div class="gp-pricing-column-circle">
                                                            <h5 class="gp-pricing-column-symbol">$</h5>
                                                            <h5 class="gp-pricing-column-price">19</h5>
                                                            <h6 class="gp-pricing-column-interval">per month</h6>
                                                        </div>
                                                    </div>
                                                    <div class="gp-pricing-column-divider"></div>
                                                    <div class="gp-pricing-column-content">
                                                        <ul>
                                                            <li>All bronze features</li>
                                                            <li>Access to most premium content</li>
                                                            <li>Upload media</li>
                                                            <li>Create and moderate groups</li>
                                                            <li>Advanced site activity features</li>
                                                            <li>Premium support</li>
                                                        </ul>
                                                    </div>
                                                    <div class="gp-pricing-column-divider"></div>
                                                    <div class="gp-pricing-column-footer"> <a href="membership-account/membership-checkout/index6435.html?level=2" class="gp-pricing-column-button">Sign Up</a></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="wpb_column vc_column_container vc_col-sm-4 bb_custom_1506681090634">
                                        <div class="vc_column-inner">
                                            <div class="wpb_wrapper">
                                                <div id="gp_pricing_column_3" class="gp-pricing-column gp-normal-column gp-style-1">
                                                    <div class="gp-pricing-column-header">
                                                        <h5 class="gp-pricing-column-title"> Gold</h5>
                                                    </div>
                                                    <div class="gp-pricing-column-costs">
                                                        <div class="gp-pricing-column-circle">
                                                            <h5 class="gp-pricing-column-symbol">$</h5>
                                                            <h5 class="gp-pricing-column-price">39</h5>
                                                            <h6 class="gp-pricing-column-interval">per month</h6>
                                                        </div>
                                                    </div>
                                                    <div class="gp-pricing-column-divider"></div>
                                                    <div class="gp-pricing-column-content">
                                                        <ul>
                                                            <li>All silver features</li>
                                                            <li>Access to all premium content</li>
                                                            <li>Create and moderate forums</li>
                                                            <li>Access to new features first</li>
                                                            <li>Ad-free site</li>
                                                            <li>Dedicated support team</li>
                                                        </ul>
                                                    </div>
                                                    <div class="gp-pricing-column-divider"></div>
                                                    <div class="gp-pricing-column-footer"> <a href="membership-account/membership-checkout/index7054.html?level=3" class="gp-pricing-column-button">Sign Up</a></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> -->
                <div class="vc_row-full-width vc_clearfix"></div>
                <div data-vc-full-width="true" data-vc-full-width-init="false" class="vc_row wpb_row vc_row-fluid vc_custom_1511127359756 gp-scrolling-gradient bb_custom_1511127359758">
                    <div class="gp-animated-gradient-column">
                        <div class="wpb_column vc_column_container vc_col-sm-12">
                            <div class="vc_column-inner vc_custom_1506938780687">
                                <div class="wpb_wrapper">
                                    <div style="color: #ffffff;text-align: center" class="vc_custom_heading vc_custom_1506936913508 bb_custom_1506936903345">Les membres de notre communauté</div>
                                    <!-- <div style="color: #ffffff;text-align: center" class="vc_custom_heading vc_custom_1506936972009 bb_custom_1506936972009 bb_custom_1506936972011">Become a part of a growing community and have access to thousands of members.</div> -->
                                    <div id="gp_buddypress_members_1" class="gp-bp-element ">
                                        <ul class="gp-bp-wrapper gp-bp-members gp-bp-round-avatars gp-align-center gp-style-classic" aria-live="polite" aria-relevant="all" aria-atomic="true">
                                            <?php foreach ($members as $member) : ?>
                                                <?php
                                                $imgsrc = ($member->profil_picture) ? 'uploads/profil_im/' . $member->profil_picture : 'assets/avatar/avatar_male.png';

                                                ?>
                                                <li class="gp-post-item odd is-online">
                                                    <a title="<?= ucfirst($member->firstname) . ' ' . ucfirst($member->lastname) ?>" href="<?= base_url() ?>user/detail/<?= $member->user_id ?>" class="gp-bp-avatar"> <span class="gp-bp-hover-effect"></span> <img loading="lazy" src="<?= base_url().$imgsrc ?>" class="avatar user-72-avatar avatar-90 photo" width="90" height="90" alt="Profile picture of Kevin Agastra" />
                                                        <div class="gp-user-online"></div>
                                                    </a>
                                                </li>
                                            <?php endforeach; ?>

                                        </ul>
                                        <input type="hidden" id="_wpnonce-members" name="_wpnonce-members" value="ff3191cada" />
                                        <input type="hidden" name="gp-members-element-max" class="gp-members-element-max" value="22" />
                                        <input type="hidden" name="gp-members-element-format" class="gp-members-element-format" value="gp-bp-round-avatars" />
                                        <input type="hidden" name="gp-members-element-cover-images" class="gp-members-element-cover-images" value="enabled" />
                                    </div>
                                    <div class="vc_btn3-container vc_btn3-center vc_custom_1615924379902 bb_custom_1615924379904 bb_custom_1615924379908"> <a onmouseleave="this.style.borderColor='#ffffff'; this.style.backgroundColor='transparent'; this.style.color='#ffffff'" onmouseenter="this.style.color='#ffffff';" style="border-color:#ffffff; color:#ffffff;" class="vc_general vc_btn3 vc_btn3-size-lg vc_btn3-shape-round vc_btn3-style-outline-custom bb_custom_1615924379904 bb_custom_1615924379908" href="<?= base_url() ?>search_member" title="Members (BuddyPress)">Voir Plus</a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="gp-animated-gradient-bg" style="background: linear-gradient(-45deg,#ee7752,#e73c7e,#39c8df,#ddeebb);"></div>
                </div>
                <div class="vc_row-full-width vc_clearfix"></div>
                <div data-vc-full-width="true" data-vc-full-width-init="false" class="vc_row wpb_row vc_row-fluid vc_custom_1506940850543 vc_row-has-fill bb_custom_1506940850545">
                    <div class="wpb_column vc_column_container vc_col-sm-12">
                        <div class="vc_column-inner vc_custom_1506938780687">
                            <div class="wpb_wrapper">
                                <div style="font-size: 36px;color: #232323;line-height: 36px;text-align: center;font-family:Roboto;font-weight:700;font-style:normal" class="vc_custom_heading vc_custom_1509111849647 bb_custom_1509111847947">Paid Membership Features</div>
                                <div style="color: #999999;text-align: center" class="vc_custom_heading vc_custom_1506947586845 bb_custom_1506947586846 bb_custom_1506947586849">Aardvark is fully integrated with the Paid Memberships Pro plugin.</div>
                                <div class="vc_row wpb_row vc_inner vc_row-fluid vc_column-gap-5 vc_row-o-equal-height vc_row-flex">
                                    <div class="gp-flex-column wpb_column vc_column_container vc_col-sm-4">
                                        <div class="vc_column-inner">
                                            <div class="wpb_wrapper">
                                                <div class="vc_icon_element vc_icon_element-outer vc_custom_1511093525775 vc_icon_element-align-left">
                                                    <div class="vc_icon_element-inner vc_icon_element-color-custom vc_icon_element-size-lg vc_icon_element-style- vc_icon_element-background-color-grey"><span class="vc_icon_element-icon vc-material vc-material-lock_outline" style="color:#39c8df !important"></span></div>
                                                </div>
                                                <div class="wpb_text_column wpb_content_element ">
                                                    <div class="wpb_wrapper">
                                                        <p><span style="color: #232323; font-size: 20px; line-height: 20px;"><strong>Restrict User Access</strong></span></p>
                                                        <p><span style="color: #999999; font-size: 16px; line-height: 24px;">Control access to specific posts, pages, categories, forums and BuddyPress content based on membership level. Show teaser content and specfic content based on the user’s membership level.</span></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="gp-flex-column wpb_column vc_column_container vc_col-sm-4">
                                        <div class="vc_column-inner">
                                            <div class="wpb_wrapper">
                                                <div class="vc_icon_element vc_icon_element-outer vc_icon_element-align-left">
                                                    <div class="vc_icon_element-inner vc_icon_element-color-custom vc_icon_element-size-lg vc_icon_element-style- vc_icon_element-background-color-grey"><span class="vc_icon_element-icon fa fa-shield" style="color:#39c8df !important"></span></div>
                                                </div>
                                                <div class="wpb_text_column wpb_content_element ">
                                                    <div class="wpb_wrapper">
                                                        <p><span style="color: #232323; font-size: 20px; line-height: 20px;"><strong>Unlimited Membership Levels</strong></span></p>
                                                        <p><span style="color: #999999; font-size: 16px; line-height: 24px;">Set up the membership levels that best fit your business, whether they are Free, Paid, or Recurring Subscriptions (Annual, Monthly, Weekly, Daily). Offer Custom Trial Periods (Free Trial, Custom-length Trial, ‘Introductory’ Pricing).</span></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="gp-flex-column wpb_column vc_column_container vc_col-sm-4">
                                        <div class="vc_column-inner">
                                            <div class="wpb_wrapper">
                                                <div class="vc_icon_element vc_icon_element-outer vc_custom_1511093541053 vc_icon_element-align-left">
                                                    <div class="vc_icon_element-inner vc_icon_element-color-custom vc_icon_element-size-lg vc_icon_element-style- vc_icon_element-background-color-grey"><span class="vc_icon_element-icon fa fa-credit-card" style="color:#39c8df !important"></span></div>
                                                </div>
                                                <div class="wpb_text_column wpb_content_element ">
                                                    <div class="wpb_wrapper">
                                                        <p><span style="color: #232323; font-size: 20px; line-height: 20px;"><strong>Popular Payment Gateways</strong></span></p>
                                                        <p><span style="color: #999999; font-size: 16px; line-height: 24px;">Accept payment from the most popular payment gateways &#8211; Stripe, Authorize.net, PayPal (Standard, Express, Website Payments Pro, and PayPal Payments Pro/Payflow), Braintree, 2Checkout, and Cybersource.</span></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="vc_row wpb_row vc_inner vc_row-fluid vc_column-gap-5 vc_row-o-equal-height vc_row-flex">
                                    <div class="gp-flex-column wpb_column vc_column_container vc_col-sm-4">
                                        <div class="vc_column-inner">
                                            <div class="wpb_wrapper">
                                                <div class="vc_icon_element vc_icon_element-outer vc_custom_1511093546252 vc_icon_element-align-left">
                                                    <div class="vc_icon_element-inner vc_icon_element-color-custom vc_icon_element-size-lg vc_icon_element-style- vc_icon_element-background-color-grey"><span class="vc_icon_element-icon fa fa-laptop" style="color:#39c8df !important"></span></div>
                                                </div>
                                                <div class="wpb_text_column wpb_content_element ">
                                                    <div class="wpb_wrapper">
                                                        <p><span style="color: #232323; font-size: 20px; line-height: 20px;"><strong>Great User Interface</strong></span></p>
                                                        <p><span style="color: #999999; font-size: 16px; line-height: 24px;">Add custom registration and profile fields. Additionally members can update their billing information or cancel their account directly on your site. Any active subscription will be cancelled at the payment gateway for you.</span></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="gp-flex-column wpb_column vc_column_container vc_col-sm-4">
                                        <div class="vc_column-inner">
                                            <div class="wpb_wrapper">
                                                <div class="vc_icon_element vc_icon_element-outer vc_custom_1511093551774 vc_icon_element-align-left">
                                                    <div class="vc_icon_element-inner vc_icon_element-color-custom vc_icon_element-size-lg vc_icon_element-style- vc_icon_element-background-color-grey"><span class="vc_icon_element-icon fa fa-link" style="color:#39c8df !important"></span></div>
                                                </div>
                                                <div class="wpb_text_column wpb_content_element ">
                                                    <div class="wpb_wrapper">
                                                        <p><span style="color: #232323; font-size: 20px; line-height: 20px;"><strong>Third Party Integration</strong></span></p>
                                                        <p><span style="color: #999999; font-size: 16px; line-height: 24px;">Integrates with Mailchimp, Constant Contact, AWeber, GetResponse, Social Login, KISSMetrics, Infusionsoft, WP Courseware, LearnDash, Post Affiliate Pro, bbPress, WooCommerce, and many more popular third party tools.</span></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="gp-flex-column wpb_column vc_column_container vc_col-sm-4">
                                        <div class="vc_column-inner">
                                            <div class="wpb_wrapper">
                                                <div class="vc_icon_element vc_icon_element-outer vc_custom_1511093557287 vc_icon_element-align-left">
                                                    <div class="vc_icon_element-inner vc_icon_element-color-custom vc_icon_element-size-lg vc_icon_element-style- vc_icon_element-background-color-grey"><span class="vc_icon_element-icon fa fa-plus-square-o" style="color:#39c8df !important"></span></div>
                                                </div>
                                                <div class="wpb_text_column wpb_content_element ">
                                                    <div class="wpb_wrapper">
                                                        <p><span style="color: #232323; font-size: 20px; line-height: 20px;"><strong>Tons of Add-ons</strong></span></p>
                                                        <p><span style="color: #999999; font-size: 16px; line-height: 24px;">Paid Memberships Pro provide a huge library of add-ons that allow you to extend Paid Memberships Pro to your needs. <a href="https://www.paidmembershipspro.com/add-ons/" target="_blank" rel="noopener noreferrer">Views add-ons</a>.</span></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="vc_row-full-width vc_clearfix"></div>
                <div data-vc-full-width="true" data-vc-full-width-init="false" class="vc_row wpb_row vc_row-fluid vc_custom_1506953501596 vc_row-has-fill">
                    <div class="wpb_column vc_column_container vc_col-sm-12">
                        <div class="vc_column-inner vc_custom_1511008768309">
                            <div class="wpb_wrapper">
                                <div id="gp_statistics_wrapper_1" class="gp-statistics-wrapper gp-stats-columns">
                                    <div class="gp-stats-col"> <i class="gp-stats-icon fa fa-commenting-o"></i>
                                        <div class="gp-stats-details">
                                            <div class="gp-stats-title">Activity</div>
                                            <div class="gp-stats-count" style="color: #ffffff">4,302</div>
                                        </div>
                                    </div>
                                    <div class="gp-stats-col"> <i class="gp-stats-icon fa fa-user-o"></i>
                                        <div class="gp-stats-details">
                                            <div class="gp-stats-title">Members</div>
                                            <div class="gp-stats-count" style="color: #ffffff">12,744</div>
                                        </div>
                                    </div>
                                    <div class="gp-stats-col"> <i class="gp-stats-icon fa fa-user-circle-o"></i>
                                        <div class="gp-stats-details">
                                            <div class="gp-stats-title">Online</div>
                                            <div class="gp-stats-count" style="color: #ffffff">125</div>
                                        </div>
                                    </div>
                                    <div class="gp-stats-col"> <i class="gp-stats-icon fa fa-users"></i>
                                        <div class="gp-stats-details">
                                            <div class="gp-stats-title">Groups</div>
                                            <div class="gp-stats-count" style="color: #ffffff">899</div>
                                        </div>
                                    </div>
                                    <div class="gp-stats-col"> <i class="gp-stats-icon fa fa-list"></i>
                                        <div class="gp-stats-details">
                                            <div class="gp-stats-title">Forums</div>
                                            <div class="gp-stats-count" style="color: #ffffff">88</div>
                                        </div>
                                    </div>
                                    <div class="gp-stats-col"> <i class="gp-stats-icon fa fa-comments-o"></i>
                                        <div class="gp-stats-details">
                                            <div class="gp-stats-title">Topics</div>
                                            <div class="gp-stats-count" style="color: #ffffff">23,543</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="vc_row-full-width vc_clearfix"></div>
            </div>
        </div>
        <div class="gp-clear"></div>
    </div>
    <div class="gp-clear"></div>
</div>