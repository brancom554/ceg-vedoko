<footer id="gp-footer" class="gp-container gp-footer-boxed gp-footer-widgets-desktop gp-has-copyright">
    <div class="gp-container">
        <div id="gp-footer-image"> <img src="<?= base_url() ?>assets/themes/aardvark/lib/images/original/logo.png" width="117" height="24" alt="Aardvark Original" class="gp-standard-image" /> <img src="<?= base_url() ?>assets/themes/aardvark/lib/images/original/logo-retina.png" width="117" height="24" alt="Aardvark Original" class="gp-retina-image" /></div>
        <div id="gp-footer-widgets">
            <div class="gp-footer-widget gp-footer-1 gp-footer-fourth">
                <div id="gp-contact-details-widget-2" class="widget widget-content gp-contact-details-widget">
                    <h3 class="widget-title widgettitle">About Us</h3>
                    <div class="gp-contact-intro">Get in touch with us in the following ways.</div>
                    <div class="gp-contact-detail gp-contact-email">
                        <div class="gp-contact-text">contactus@aardvark.com</div>
                    </div>
                    <div class="gp-contact-detail gp-contact-phone">
                        <div class="gp-contact-text">+(44) 0234 123 7653</div>
                    </div>
                </div>
            </div>
            <div class="gp-footer-widget gp-footer-2 gp-footer-fourth">
                <div id="text-5" class="widget widget-content widget_text">
                    <h3 class="widget-title widgettitle">Community</h3>
                    <div class="textwidget">
                        <ul>
                            <li><a href="#">Activity</a></li>
                            <li><a href="#">Members</a></li>
                            <li><a href="#">Groups</a></li>
                            <li><a href="#">Forums</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="gp-footer-widget gp-footer-3 gp-footer-fourth">
                <div id="text-3" class="widget widget-content widget_text">
                    <h3 class="widget-title widgettitle">Our Services</h3>
                    <div class="textwidget">
                        <ul>
                            <li><a href="#">Our mission</a></li>
                            <li><a href="#">Help/Contact Us</a></li>
                            <li><a href="#">Privacy Policy</a></li>
                            <li><a href="#">Cookie Policy</a></li>
                            <li><a href="#">Terms &amp; Conditions</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="gp-footer-widget gp-footer-4 gp-footer-fourth">
                <div id="text-7" class="widget widget-content widget_text">
                    <h3 class="widget-title widgettitle">Admin</h3>
                    <div class="textwidget">
                        <ul>
                            <li><a href="#">Advertising</a></li>
                            <li><a href="#">Press</a></li>
                            <li><a href="#">Affiliation</a></li>
                            <li><a href="#">Business development</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div id="gp-copyright">
            <div id="gp-copyright-text"> Copyright &copy; 2021 <a href="https://themeforest.net/user/GhostPool/portfolio?ref=GhostPool" rel="nofollow">GhostPool.com</a></div>
            <nav id="gp-footer-nav" class="gp-nav">
                <ul id="menu-footer-menu" class="menu">
                    <li class="nav-menu-item-38 gp-standard-menu gp-show-all  main-menu-item  menu-item-even menu-item-depth-0  menu-item menu-item-type-custom menu-item-object-custom"><a href="#" class="menu-link main-menu-link">About</a></li>
                    <li class="nav-menu-item-39 gp-standard-menu gp-show-all  main-menu-item  menu-item-even menu-item-depth-0  menu-item menu-item-type-custom menu-item-object-custom"><a href="#" class="menu-link main-menu-link">Pricing</a></li>
                    <li class="nav-menu-item-40 gp-standard-menu gp-show-all  main-menu-item  menu-item-even menu-item-depth-0  menu-item menu-item-type-custom menu-item-object-custom"><a href="#" class="menu-link main-menu-link">Docs</a></li>
                    <li class="nav-menu-item-41 gp-standard-menu gp-show-all  main-menu-item  menu-item-even menu-item-depth-0  menu-item menu-item-type-custom menu-item-object-custom"><a href="#" class="menu-link main-menu-link">Support</a></li>
                    <li class="nav-menu-item-42 gp-standard-menu gp-show-all  main-menu-item  menu-item-even menu-item-depth-0  menu-item menu-item-type-custom menu-item-object-custom"><a href="#" class="menu-link main-menu-link">How Tos</a></li>
                </ul>
            </nav>
        </div>
    </div>
</footer>
</div>
</div>
<div id="gp-mobile-nav-bg"></div>
<div id="gp-close-mobile-nav-button"></div>
<nav id="gp-mobile-primary-nav" class="gp-mobile-nav">
    <ul id="gp-mobile-primary-menu" class="menu">
        <li class="nav-menu-item-396 gp-standard-menu gp-show-all  main-menu-item  menu-item-even menu-item-depth-0  menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-2 current_page_item"><a href="index.html" class="menu-link main-menu-link">Home</a></li>
        <li class="nav-menu-item-113 gp-standard-menu gp-show-all  main-menu-item  menu-item-even menu-item-depth-0  menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children"><a href="#" class="menu-link main-menu-link">Membership</a>
            <ul class="sub-menu menu-odd  menu-depth-1">
                <li class="nav-menu-item-596 gp-standard-menu gp-show-all  sub-menu-item  menu-item-odd menu-item-depth-1  menu-item menu-item-type-custom menu-item-object-custom"><a href="activity/index.html" class="menu-link sub-menu-link">Activity</a></li>
                <li class="nav-menu-item-597 gp-standard-menu gp-show-all  sub-menu-item  menu-item-odd menu-item-depth-1  menu-item menu-item-type-custom menu-item-object-custom"><a href="members/index.html" class="menu-link sub-menu-link">Members</a></li>
                <li class="nav-menu-item-599 gp-standard-menu gp-show-all  sub-menu-item  menu-item-odd menu-item-depth-1  menu-item menu-item-type-custom menu-item-object-custom"><a href="forums/index.html" class="menu-link sub-menu-link">Forums</a></li>
                <li class="nav-menu-item-598 gp-standard-menu gp-show-all  sub-menu-item  menu-item-odd menu-item-depth-1  menu-item menu-item-type-custom menu-item-object-custom"><a href="groups/index.html" class="menu-link sub-menu-link">Groups</a></li>
                <li class="nav-menu-item-122 gp-standard-menu gp-show-all  sub-menu-item  menu-item-odd menu-item-depth-1  menu-item menu-item-type-post_type menu-item-object-page"><a href="membership-account/membership-levels/index.html" class="menu-link sub-menu-link">Membership Levels Page (Default)</a></li>
                <li class="nav-menu-item-733 gp-standard-menu gp-show-all  sub-menu-item  menu-item-odd menu-item-depth-1  menu-item menu-item-type-custom menu-item-object-custom"><a href="https://aardvark.ghostpool.com/trial/membership-account/membership-levels/" class="menu-link sub-menu-link">Custom Membership Levels Page (Custom)</a></li>
                <li class="nav-menu-item-129 gp-standard-menu gp-show-all  sub-menu-item  menu-item-odd menu-item-depth-1  menu-item menu-item-type-post_type menu-item-object-post"><a href="news/globally-redefine-leading-edge-outsourcing-for-interoperable-web-readiness/index.html" class="menu-link sub-menu-link">100% restricted post</a></li>
                <li class="nav-menu-item-734 gp-standard-menu gp-show-all  sub-menu-item  menu-item-odd menu-item-depth-1  menu-item menu-item-type-custom menu-item-object-custom"><a href="https://aardvark.ghostpool.com/trial/standard/restricted-content-within-post-2/" class="menu-link sub-menu-link">Restricted content within post</a></li>
            </ul>
        </li>
        <li class="nav-menu-item-71 gp-standard-menu gp-show-all  main-menu-item  menu-item-even menu-item-depth-0  menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children"><a href="#" class="menu-link main-menu-link">Blog</a>
            <ul class="sub-menu menu-odd  menu-depth-1">
                <li class="nav-menu-item-88 gp-standard-menu gp-show-all  sub-menu-item  menu-item-odd menu-item-depth-1  menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children"><a href="#" class="menu-link sub-menu-link">Blog Masonry</a>
                    <ul class="sub-menu menu-even sub-sub-menu menu-depth-2">
                        <li class="nav-menu-item-264 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-page"><a href="blog/blog-masonry-classic-center/index.html" class="menu-link sub-menu-link">Blog Masonry – Classic (Center)</a></li>
                        <li class="nav-menu-item-265 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-page"><a href="blog/blog-masonry-classic-left/index.html" class="menu-link sub-menu-link">Blog Masonry – Classic (Left)</a></li>
                        <li class="nav-menu-item-266 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-page"><a href="blog/blog-masonry-classic-sidebar/index.html" class="menu-link sub-menu-link">Blog Masonry – Classic (Sidebar)</a></li>
                        <li class="nav-menu-item-270 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-page"><a href="blog/blog-masonry-modern-center/index.html" class="menu-link sub-menu-link">Blog Masonry – Modern (Centered)</a></li>
                        <li class="nav-menu-item-271 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-page"><a href="blog/blog-masonry-modern-left/index.html" class="menu-link sub-menu-link">Blog Masonry – Modern (Left)</a></li>
                        <li class="nav-menu-item-267 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-page"><a href="blog/blog-masonry-modern-sidebar/index.html" class="menu-link sub-menu-link">Blog Masonry – Modern (Sidebar)</a></li>
                    </ul>
                </li>
                <li class="nav-menu-item-87 gp-standard-menu gp-show-all  sub-menu-item  menu-item-odd menu-item-depth-1  menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children"><a href="#" class="menu-link sub-menu-link">Blog Grid</a>
                    <ul class="sub-menu menu-even sub-sub-menu menu-depth-2">
                        <li class="nav-menu-item-250 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-page"><a href="blog/blog-grid-classic-2-columns/index.html" class="menu-link sub-menu-link">Blog Grid – Classic (2 Columns)</a></li>
                        <li class="nav-menu-item-251 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-page"><a href="blog/blog-grid-classic-3-columns/index.html" class="menu-link sub-menu-link">Blog Grid – Classic (3 Columns)</a></li>
                        <li class="nav-menu-item-252 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-page"><a href="blog/blog-grid-classic-4-columns/index.html" class="menu-link sub-menu-link">Blog Grid – Classic (4 Columns)</a></li>
                        <li class="nav-menu-item-253 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-page"><a href="blog/blog-grid-modern-2-columns/index.html" class="menu-link sub-menu-link">Blog Grid – Modern (2 Columns)</a></li>
                        <li class="nav-menu-item-254 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-page"><a href="blog/blog-grid-modern-3-columns/index.html" class="menu-link sub-menu-link">Blog Grid – Modern (3 Columns)</a></li>
                        <li class="nav-menu-item-255 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-page"><a href="blog/blog-grid-modern-4-columns/index.html" class="menu-link sub-menu-link">Blog Grid – Modern (4 Columns)</a></li>
                    </ul>
                </li>
                <li class="nav-menu-item-89 gp-standard-menu gp-show-all  sub-menu-item  menu-item-odd menu-item-depth-1  menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children"><a href="#" class="menu-link sub-menu-link">Blog List</a>
                    <ul class="sub-menu menu-even sub-sub-menu menu-depth-2">
                        <li class="nav-menu-item-260 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-page"><a href="blog/blog-list-classic-no-sidebar/index.html" class="menu-link sub-menu-link">Blog List – Classic</a></li>
                        <li class="nav-menu-item-261 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-page"><a href="blog/blog-list-classic-sidebar/index.html" class="menu-link sub-menu-link">Blog List – Classic (Sidebar)</a></li>
                        <li class="nav-menu-item-262 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-page"><a href="blog/blog-list-modern/index.html" class="menu-link sub-menu-link">Blog List – Modern</a></li>
                        <li class="nav-menu-item-263 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-page"><a href="blog/blog-list-modern-1/index.html" class="menu-link sub-menu-link">Blog List – Modern (Sidebar)</a></li>
                    </ul>
                </li>
                <li class="nav-menu-item-90 gp-standard-menu gp-show-all  sub-menu-item  menu-item-odd menu-item-depth-1  menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children"><a href="#" class="menu-link sub-menu-link">Blog Large</a>
                    <ul class="sub-menu menu-even sub-sub-menu menu-depth-2">
                        <li class="nav-menu-item-256 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-page"><a href="blog/blog-large-classic-centered/index.html" class="menu-link sub-menu-link">Blog Large – Classic (Centered)</a></li>
                        <li class="nav-menu-item-257 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-page"><a href="blog/blog-large-classic-left/index.html" class="menu-link sub-menu-link">Blog Large – Classic (Left)</a></li>
                        <li class="nav-menu-item-258 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-page"><a href="blog/blog-large-modern-center/index.html" class="menu-link sub-menu-link">Blog Large – Modern (Center)</a></li>
                        <li class="nav-menu-item-259 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-page"><a href="blog/blog-large-modern-left/index.html" class="menu-link sub-menu-link">Blog Large – Modern (Left)</a></li>
                    </ul>
                </li>
                <li class="nav-menu-item-94 gp-standard-menu gp-show-all  sub-menu-item  menu-item-odd menu-item-depth-1  menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children"><a href="#" class="menu-link sub-menu-link">Post Layouts</a>
                    <ul class="sub-menu menu-even sub-sub-menu menu-depth-2">
                        <li class="nav-menu-item-385 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-post"><a href="news/conveniently-provide-access-to-professional-methods/index.html" class="menu-link sub-menu-link">Full width post</a></li>
                        <li class="nav-menu-item-388 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-post"><a href="news/energistically-syndicate-backward-compatible-scenarios/index.html" class="menu-link sub-menu-link">Post with left sidebar</a></li>
                        <li class="nav-menu-item-392 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-post"><a href="news/intrinsicly-streamline-go-forward-internal/index.html" class="menu-link sub-menu-link">Post with two sidebars</a></li>
                        <li class="nav-menu-item-98 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-post"><a href="news/continually-integrate-progressive-action/index.html" class="menu-link sub-menu-link">Post with full width header</a></li>
                        <li class="nav-menu-item-103 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-post"><a href="news/why-matrix-high-quality-synergy/index.html" class="menu-link sub-menu-link">Post with full page background</a></li>
                        <li class="nav-menu-item-104 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-post"><a href="news/completely-promote-frictionless/index.html" class="menu-link sub-menu-link">Post with gallery slider</a></li>
                        <li class="nav-menu-item-105 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-post"><a href="news/appropriately-re-engineer-virtual-supply-chains-without/index.html" class="menu-link sub-menu-link">Post with video</a></li>
                    </ul>
                </li>
            </ul>
        </li>
        <li class="nav-menu-item-112 gp-megamenu gp-show-all  main-menu-item  menu-item-even menu-item-depth-0  menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children"><a href="#" class="menu-link main-menu-link">Elements</a>
            <ul class="sub-menu menu-odd  menu-depth-1">
                <li>
                    <ul class="sub-menu menu-even sub-sub-menu menu-depth-2">
                        <li class="nav-menu-item-323 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-page"><a href="elements/accordions-and-toggles/index.html" class="menu-link sub-menu-link"><i class="gp-menu-icon fa fa-align-justify"></i>Accordions and Toggles</a></li>
                        <li class="nav-menu-item-324 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-page"><a href="elements/activity-buddypress/index.html" class="menu-link sub-menu-link"><i class="gp-menu-icon fa fa-comments"></i>Activity (BuddyPress)</a></li>
                        <li class="nav-menu-item-325 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-page"><a href="elements/buttons/index.html" class="menu-link sub-menu-link"><i class="gp-menu-icon fa fa-square"></i>Buttons</a></li>
                        <li class="nav-menu-item-438 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-page"><a href="elements/blog-grids-masonry/index.html" class="menu-link sub-menu-link"><i class="gp-menu-icon fa fa-file-text-o"></i>Blog Grids &#038; Masonry</a></li>
                        <li class="nav-menu-item-439 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-page"><a href="elements/blog-lists/index.html" class="menu-link sub-menu-link"><i class="gp-menu-icon fa fa-file-text-o"></i>Blog Lists</a></li>
                    </ul>
                </li>
                <li>
                    <ul class="sub-menu menu-even sub-sub-menu menu-depth-2">
                        <li class="nav-menu-item-326 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-page"><a href="elements/call-to-actions/index.html" class="menu-link sub-menu-link"><i class="gp-menu-icon fa fa-warning"></i>Call To Actions</a></li>
                        <li class="nav-menu-item-327 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-page"><a href="elements/charts-bars/index.html" class="menu-link sub-menu-link"><i class="gp-menu-icon fa fa-bar-chart-o"></i>Charts &#038; Bars</a></li>
                        <li class="nav-menu-item-651 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-page"><a href="elements/featured-boxes/index.html" class="menu-link sub-menu-link"><i class="gp-menu-icon fa fa-th"></i>Featured Boxes</a></li>
                        <li class="nav-menu-item-328 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-page"><a href="elements/google-maps/index.html" class="menu-link sub-menu-link"><i class="gp-menu-icon fa fa-map-marker"></i>Google Maps</a></li>
                        <li class="nav-menu-item-329 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-page"><a href="elements/groups-buddypress/index.html" class="menu-link sub-menu-link"><i class="gp-menu-icon fa fa-users"></i>Groups (BuddyPress)</a></li>
                    </ul>
                </li>
                <li>
                    <ul class="sub-menu menu-even sub-sub-menu menu-depth-2">
                        <li class="nav-menu-item-330 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-page"><a href="elements/hover-boxes/index.html" class="menu-link sub-menu-link"><i class="gp-menu-icon fa fa-cube"></i>Hover Boxes</a></li>
                        <li class="nav-menu-item-331 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-page"><a href="elements/icons/index.html" class="menu-link sub-menu-link"><i class="gp-menu-icon fa fa-check-circle"></i>Icons</a></li>
                        <li class="nav-menu-item-332 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-page"><a href="elements/image-post-carousels/index.html" class="menu-link sub-menu-link"><i class="gp-menu-icon fa fa-arrows-h"></i>Image/Post Carousels</a></li>
                        <li class="nav-menu-item-333 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-page"><a href="elements/image-galleries/index.html" class="menu-link sub-menu-link"><i class="gp-menu-icon fa fa-image"></i>Image Galleries</a></li>
                        <li class="nav-menu-item-334 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-page"><a href="elements/members-buddypress/index.html" class="menu-link sub-menu-link"><i class="gp-menu-icon fa fa-user"></i>Members (BuddyPress)</a></li>
                    </ul>
                </li>
                <li>
                    <ul class="sub-menu menu-even sub-sub-menu menu-depth-2">
                        <li class="nav-menu-item-335 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-page"><a href="elements/particles/index.html" class="menu-link sub-menu-link"><i class="gp-menu-icon fa fa-connectdevelop"></i>Particles</a></li>
                        <li class="nav-menu-item-336 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-page"><a href="elements/post-submission/index.html" class="menu-link sub-menu-link"><i class="gp-menu-icon fa fa-wpforms"></i>Post Submission</a></li>
                        <li class="nav-menu-item-339 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-page"><a href="elements/pricing-tables/index.html" class="menu-link sub-menu-link"><i class="gp-menu-icon fa fa-dollar"></i>Pricing Tables</a></li>
                        <li class="nav-menu-item-340 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-page"><a href="elements/showcase/index.html" class="menu-link sub-menu-link"><i class="gp-menu-icon fa fa-ticket"></i>Showcase</a></li>
                        <li class="nav-menu-item-848 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-page"><a href="elements/single-images/index.html" class="menu-link sub-menu-link"><i class="gp-menu-icon fa fa-image"></i>Single Images</a></li>
                    </ul>
                </li>
                <li>
                    <ul class="sub-menu menu-even sub-sub-menu menu-depth-2">
                        <li class="nav-menu-item-341 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-page"><a href="elements/statistics/index.html" class="menu-link sub-menu-link"><i class="gp-menu-icon fa fa-area-chart"></i>Statistics</a></li>
                        <li class="nav-menu-item-342 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-page"><a href="elements/tabs-horizontal/index.html" class="menu-link sub-menu-link"><i class="gp-menu-icon fa fa-folder"></i>Tabs (Horizontal)</a></li>
                        <li class="nav-menu-item-343 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-page"><a href="elements/tabs-vertical/index.html" class="menu-link sub-menu-link"><i class="gp-menu-icon fa fa-folder-o"></i>Tabs (Vertical)</a></li>
                        <li class="nav-menu-item-344 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-page"><a href="elements/team/index.html" class="menu-link sub-menu-link"><i class="gp-menu-icon fa fa-columns"></i>Team</a></li>
                        <li class="nav-menu-item-345 gp-standard-menu gp-show-all  sub-menu-item sub-sub-menu-item menu-item-even menu-item-depth-2  menu-item menu-item-type-post_type menu-item-object-page"><a href="elements/testimonials/index.html" class="menu-link sub-menu-link"><i class="gp-menu-icon fa fa-heart"></i>Testimonials</a></li>
                    </ul>
                </li>
            </ul>
        </li>
        <li class="nav-menu-item-212 gp-standard-menu gp-show-all  main-menu-item  menu-item-even menu-item-depth-0  menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children"><a href="shop/index.html" class="menu-link main-menu-link">Shop</a>
            <ul class="sub-menu menu-odd  menu-depth-1">
                <li class="nav-menu-item-213 gp-standard-menu gp-show-all  sub-menu-item  menu-item-odd menu-item-depth-1  menu-item menu-item-type-post_type menu-item-object-page"><a href="shop/index.html" class="menu-link sub-menu-link">Shop</a></li>
                <li class="nav-menu-item-211 gp-standard-menu gp-show-all  sub-menu-item  menu-item-odd menu-item-depth-1  menu-item menu-item-type-post_type menu-item-object-page"><a href="my-account/index.html" class="menu-link sub-menu-link">My Account</a></li>
                <li class="nav-menu-item-209 gp-standard-menu gp-show-all  sub-menu-item  menu-item-odd menu-item-depth-1  menu-item menu-item-type-post_type menu-item-object-page"><a href="cart/index.html" class="menu-link sub-menu-link">Cart</a></li>
                <li class="nav-menu-item-210 gp-standard-menu gp-show-all  sub-menu-item  menu-item-odd menu-item-depth-1  menu-item menu-item-type-post_type menu-item-object-page"><a href="checkout/index.html" class="menu-link sub-menu-link">Checkout</a></li>
            </ul>
        </li>
    </ul>
</nav>
<div id="login">
    <div id="gp-login-modal">
        <div id="gp-login-close"></div>
        <div class="gp-login-register-form">
            <div class="gp-login-form-wrapper">
                <h5 class="gp-login-title">Se connecter</h5>
                <form class="gp-login-form" action="" method="post">
                    <p class="username gp-input">
                        <input type="text" id="login_email" class="user_login" value="" size="20" placeholder="Email" required />
                    </p>
                    <p class="password gp-input">
                        <input type="password" id="login_pass" class="user_pass" size="20" placeholder="Mot de passe" required />
                    </p>
                    <!-- <p class="rememberme gp-input">
                        <input name="rememberme" class="rememberme" type="checkbox" value="forever" /> Se sourvenir de moi
                    </p> -->
                    <div class="gp-social-login gp-input">
                        <div class="gp-login-or-lines">
                            <div class="gp-login-or-left-line"></div>
                            <!-- <div class="gp-login-or-text">or</div> -->
                            <div class="gp-login-or-right-line"></div>
                        </div>
                        <style type="text/css">
                            .wp-social-login-connect-with {}

                            .wp-social-login-provider-list {}

                            .wp-social-login-provider-list a {}

                            .wp-social-login-provider-list img {}

                            .wsl_connect_with_provider {}
                        </style>

                    </div>
                    <div id="smtdiv">
                        <input type="button" onclick="login()" name="" id="login_submit" class="wp-submit gp-input" value="Connexion" />
                    </div>
                    <div id="boxloader" style="display: none;">
                        <p id="login_loader"></p>
                    </div>
                    <div class="gp-login-results"></div>
                    <!-- <div class="gp-login-links"> <a href="register/index.html" class="gp-bp-register-link">Register</a> <a href="#" class="gp-lost-password-link">Lost Password</a></div> -->

                </form>
            </div>
            <div class="gp-lost-password-form-wrapper">
                <h5 class="gp-login-title">Lost Password</h5>
                <form name="lostpasswordform" class="gp-lost-password-form" action="#" method="post">
                    <p class="gp-login-desc gp-input">Please enter your username or email address. You will receive a link to create a new password via email.</p>
                    <p class="gp-input">
                        <input type="text" autocomplete="off" name="user_login" class="user_login" value="" size="20" placeholder="Username or Email" required />
                    </p>
                    <input type="submit" name="wp-submit" class="wp-submit gp-input" value="Reset Password" />
                    <div class="gp-login-results"></div>
                    <div id="error_login"></div>
                    <div class="gp-login-links"> <a href="#" class="gp-login-link">Sign In</a></div>
                </form>
            </div>
        </div>
    </div>
</div>
<div data-theiaStickySidebar-sidebarSelector='".gp-sidebar"' data-theiaStickySidebar-options='{"containerSelector":".gp-inner-container","additionalMarginTop":100,"additionalMarginBottom":20,"updateSidebarHeight":false,"minWidth":1081,"sidebarBehavior":"modern","disableOnResponsiveLayouts":true}'></div>

<script>
    function register() {
        // alert("ok");
        // $("#signup_submit").attr("desabled", true);
        $("#signupbtn").hide();
        $("#loader").show();
        $("#loadertxt").html('Traitement en cours...')
        var lastname = $("#lastname").val();
        var firstname = $("#firstname").val();
        var phone = $("#phone").val();
        var gender = $("#gender").val();
        var email = $("#email").val();
        var password = $("#password").val();
        var password_conf = $("#password_confirm").val();
        var prom = $("#prom").val();
        var userclasse = $("#class").val();
        var ref_id = $("#ref_id").val();
        $.ajax({
            method: "POST",
            url: "<?= base_url() ?>auth/signup",
            data: {
                lastname: lastname,
                firstname: firstname,
                phone: phone,
                gender: gender,
                email: email,
                password: password,
                password_conf: password_conf,
                proom: prom,
                userclasse: userclasse,
                ref_id: ref_id
            },
            success: function(msg) {
                console.log(msg)
                var val = msg.split("||");
                if (val[0] == "false") {
                    // $("#message").show();
                    // $("#error_message").html(val[1]);
                    toastr.error(val[1])
                    $("#signupbtn").show();
                    $("#loader").hide();
                    $("#loadertxt").html('')
                } else if (val[0] == "true") {
                    // $("#message").hide();
                    toastr.success(val[1])
                    $("#signupbtn").show();
                    $("#loader").hide();
                    $("#loadertxt").html('')
                    $("#signup_form")[0].reset();
                    location.reload();
                    // $("#click_login").click();
                }
            }
        })
    }

    function login() {
        // alert("ok")
        $("#smtdiv").hide()
        $("#login_loader").html('Connexion en cours...');
        var email = $("#login_email").val();
        var password = $("#login_pass").val();
        // console.log(email+password);

        $.ajax({
            mothod: "POST",
            url: "<?= base_url() ?>auth/login",
            data: {
                email: email,
                password: password
            },
            success: function(msg) {
                console.log(msg);
                var val = msg.split("||");
                if (val[0] == "false") {
                    // $("#error_login").html(val[1]);
                    toastr.error(val[1])
                    $("#smtdiv").show()
                } else if (val[0] == "true") {
                    toastr.success(val[1])
                    location.reload();
                }
            }
        })
    }
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/js/bootstrap.min.js" integrity="sha384-PsUw7Xwds7x08Ew3exXhqzbhuEYmA2xnwc8BuD6SEr+UmEHlX8/MCltYEodzWA4u" crossorigin="anonymous"></script>
<script type="text/html" id="wpb-modifications"></script>
<script type="text/javascript">
    (function() {
        var c = document.body.className;
        c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
        document.body.className = c;
    })();
</script>
<link rel='stylesheet' id='vc_google_fonts_roboto100100italic300300italicregularitalic500500italic700700italic900900italic-css' href='https://fonts.googleapis.com/css?family=Roboto%3A100%2C100italic%2C300%2C300italic%2Cregular%2Citalic%2C500%2C500italic%2C700%2C700italic%2C900%2C900italic&amp;ver=6.7.0' type='text/css' media='all' />
<style id='ghostpool-pricing-column-inline-css' type='text/css'>
    #gp_pricing_column_1 .gp-pricing-column-title {
        color: #ffffff;
    }

    #gp_pricing_column_1 .gp-pricing-column-costs {
        background-color: #ffffff;
    }

    #gp_pricing_column_1 .gp-pricing-column-content {
        background-color: #ffffff;
    }

    #gp_pricing_column_1 .gp-pricing-column-footer,
    #gp_pricing_column_1.gp-pricing-column {
        background-color: #ffffff;
    }

    #gp_pricing_column_1 .gp-pricing-column-button {
        color: #ffffff;
    }

    #gp_pricing_column_2 .gp-pricing-column-title {
        color: #ffffff;
    }

    #gp_pricing_column_2 .gp-pricing-column-costs {
        background-color: #ffffff;
    }

    #gp_pricing_column_2 .gp-pricing-column-content {
        background-color: #ffffff;
    }

    #gp_pricing_column_2 .gp-pricing-column-footer,
    #gp_pricing_column_2.gp-pricing-column {
        background-color: #ffffff;
    }

    #gp_pricing_column_2 .gp-pricing-column-button {
        color: #ffffff;
    }

    #gp_pricing_column_3 .gp-pricing-column-title {
        color: #ffffff;
    }

    #gp_pricing_column_3 .gp-pricing-column-costs {
        background-color: #ffffff;
    }

    #gp_pricing_column_3 .gp-pricing-column-content {
        background-color: #ffffff;
    }

    #gp_pricing_column_3 .gp-pricing-column-footer,
    #gp_pricing_column_3.gp-pricing-column {
        background-color: #ffffff;
    }

    #gp_pricing_column_3 .gp-pricing-column-button {
        color: #ffffff;
    }
</style>
<style id='ghostpool-contact-details-widget-inline-css' type='text/css'>
    #gp-contact-details-widget-2 .gp-contact-detail:before {
        color: ;
    }

    #gp-contact-details-widget-2 .gp-contact-detail {
        color: ;
    }
</style>
<script type='text/javascript' id='rtmedia-main-js-extra'>
    var bp_template_pack = "legacy";
    var RTMedia_Main_JS = {
        "media_delete_confirmation": "Are you sure you want to delete this media?",
        "rtmedia_ajaxurl": "https:\/\/aardvark.ghostpool.com\/original\/wp-admin\/admin-ajax.php",
        "media_delete_success": "Media file deleted successfully."
    };
    var rtmedia_ajax_url = "index.html\/\/aardvark.ghostpool.com\/original\/wp-admin\/admin-ajax.php";
    var rtmedia_media_slug = "media";
    var rtmedia_lightbox_enabled = "1";
    var rtmedia_direct_upload_enabled = "0";
    var rtmedia_gallery_reload_on_upload = "1";
    var rtmedia_empty_activity_msg = "Please enter some content to post.";
    var rtmedia_empty_comment_msg = "Empty comment is not allowed.";
    var rtmedia_media_delete_confirmation = "Are you sure you want to delete this media?";
    var rtmedia_media_comment_delete_confirmation = "Are you sure you want to delete this comment?";
    var rtmedia_album_delete_confirmation = "Are you sure you want to delete this Album?";
    var rtmedia_drop_media_msg = "Drop files here";
    var rtmedia_album_created_msg = " album created successfully.";
    var rtmedia_something_wrong_msg = "Something went wrong. Please try again.";
    var rtmedia_empty_album_name_msg = "Enter an album name.";
    var rtmedia_max_file_msg = "Max file Size Limit : ";
    var rtmedia_allowed_file_formats = "Allowed File Formats";
    var rtmedia_select_all_visible = "Select All Visible";
    var rtmedia_unselect_all_visible = "Unselect All Visible";
    var rtmedia_no_media_selected = "Please select some media.";
    var rtmedia_selected_media_delete_confirmation = "Are you sure you want to delete the selected media?";
    var rtmedia_selected_media_move_confirmation = "Are you sure you want to move the selected media?";
    var rtmedia_waiting_msg = "Waiting";
    var rtmedia_uploaded_msg = "Uploaded";
    var rtmedia_uploading_msg = "Uploading";
    var rtmedia_upload_failed_msg = "Failed";
    var rtmedia_close = "Close";
    var rtmedia_edit = "Edit";
    var rtmedia_delete = "Delete";
    var rtmedia_edit_media = "Edit Media";
    var rtmedia_remove_from_queue = "Remove from queue";
    var rtmedia_add_more_files_msg = "Add more files";
    var rtmedia_file_extension_error_msg = "File not supported";
    var rtmedia_more = "more";
    var rtmedia_less = "less";
    var rtmedia_read_more = "Read more";
    var rtmedia__show_less = "Show less";
    var rtmedia_activity_text_with_attachment = "disable";
    var rtmedia_delete_uploaded_media = "This media is uploaded. Are you sure you want to delete this media?";
    var rtm_wp_version = "5.8";
    var rtmedia_main_js_strings = {
        "rtmedia_albums": "Albums",
        "privacy_update_success": "Privacy updated successfully.",
        "privacy_update_error": "Couldn't change privacy, please try again."
    };
    var rtmedia_masonry_layout = "true";
    var rtmedia_masonry_layout_activity = "true";
    var rtmedia_media_size_config = {
        "photo": {
            "thumb": {
                "width": "150",
                "height": "150",
                "crop": "1"
            },
            "medium": {
                "width": "320",
                "height": "240",
                "crop": "1"
            },
            "large": {
                "width": "800",
                "height": "0",
                "crop": "1"
            }
        },
        "video": {
            "activity_media": {
                "width": "320",
                "height": "240"
            },
            "single_media": {
                "width": "640",
                "height": "480"
            }
        },
        "music": {
            "activity_media": {
                "width": "320"
            },
            "single_media": {
                "width": "640"
            }
        },
        "featured": {
            "default": {
                "width": "100",
                "height": "100",
                "crop": "1"
            }
        }
    };
    var rtmedia_disable_media_in_commented_media = "1";
    var rtmedia_disable_media_in_commented_media_text = "Adding media in Comments is not allowed";
</script>
<script type='text/javascript' id='rtmedia-backbone-js-extra'>
    var template_url = "index.html\/\/aardvark.ghostpool.com\/original\/wp-admin\/admin-ajax.php?action=rtmedia_get_template&template=media-gallery-item";
    var rtMedia_plupload_config = {
        "url": "\/original\/upload\/",
        "runtimes": "html5,flash,html4",
        "browse_button": "rtMedia-upload-button",
        "container": "rtmedia-upload-container",
        "drop_element": "drag-drop-area",
        "filters": [{
            "title": "Media Files",
            "extensions": "jpg,jpeg,png,gif,mp4,mp3"
        }],
        "max_file_size": "2.9296875M",
        "multipart": "1",
        "urlstream_upload": "1",
        "flash_swf_url": "https:\/\/aardvark.ghostpool.com\/original\/wp-includes\/js\/plupload\/plupload.flash.swf",
        "silverlight_xap_url": "https:\/\/aardvark.ghostpool.com\/original\/wp-includes\/js\/plupload\/plupload.silverlight.xap",
        "file_data_name": "rtmedia_file",
        "multi_selection": "1",
        "multipart_params": {
            "redirect": "no",
            "redirection": "false",
            "action": "wp_handle_upload",
            "_wp_http_referer": "\/original\/",
            "mode": "file_upload",
            "rtmedia_upload_nonce": "95f52bd84a"
        },
        "max_file_size_msg": "2.9296875M"
    };
    var rMedia_loading_media = "index.html\/\/aardvark.ghostpool.com\/original\/wp-content\/plugins\/buddypress-media\/app\/assets\/admin\/img\/boxspinner.gif";
    var rtmedia_media_thumbs = {
        "photo": "https:\/\/aardvark.ghostpool.com\/original\/wp-content\/plugins\/buddypress-media\/app\/assets\/admin\/img\/image_thumb.png",
        "video": "https:\/\/aardvark.ghostpool.com\/original\/wp-content\/plugins\/buddypress-media\/app\/assets\/admin\/img\/video_thumb.png",
        "music": "https:\/\/aardvark.ghostpool.com\/original\/wp-content\/plugins\/buddypress-media\/app\/assets\/admin\/img\/audio_thumb.png"
    };
    var rtmedia_set_featured_image_msg = "Featured media set successfully.";
    var rtmedia_unset_featured_image_msg = "Featured media removed successfully.";
    var rtmedia_edit_media_info_upload = {
        "title": "Title:",
        "description": "Description:"
    };
    var rtmedia_no_media_found = "Oops !! There's no media found for the request !!";
    var bp_template_pack = "legacy";
    var rtmedia_backbone_strings = {
        "rtm_edit_file_name": "Edit File Name"
    };
    var rtmedia_load_more_or_pagination = "load_more";
    var rtmedia_bp_enable_activity = "1";
    var rtmedia_upload_progress_error_message = "There are some uploads in progress. Do you want to cancel them?";
    var rtmedia_media_disabled_error_message = "Media upload is disabled. Please Enable at least one media type to proceed.";
    var rtmedia_exteansions = {
        "photo": ["jpg", "jpeg", "png", "gif"],
        "video": ["mp4"],
        "music": ["mp3"]
    };
    var rtMedia_update_plupload_comment = {
        "url": "\/original\/upload\/",
        "runtimes": "html5,flash,html4",
        "browse_button": "rtmedia-comment-media-upload",
        "container": "rtmedia-comment-media-upload-container",
        "filters": [{
            "title": "Media Files",
            "extensions": "jpg,jpeg,png,gif,mp4,mp3"
        }],
        "max_file_size": "2.9296875M",
        "multipart": "1",
        "urlstream_upload": "1",
        "flash_swf_url": "https:\/\/aardvark.ghostpool.com\/original\/wp-includes\/js\/plupload\/plupload.flash.swf",
        "silverlight_xap_url": "https:\/\/aardvark.ghostpool.com\/original\/wp-includes\/js\/plupload\/plupload.silverlight.xap",
        "file_data_name": "rtmedia_file",
        "multi_selection": "",
        "multipart_params": {
            "redirect": "no",
            "redirection": "false",
            "action": "wp_handle_upload",
            "_wp_http_referer": "\/original\/",
            "mode": "file_upload",
            "rtmedia_upload_nonce": "95f52bd84a"
        },
        "max_file_size_msg": "100M"
    };
    var rMedia_loading_file = "index.html\/\/aardvark.ghostpool.com\/original\/wp-admin\/images\/loading.gif";
</script>
<script type='text/javascript' id='woocommerce-js-extra'>
    var woocommerce_params = {
        "ajax_url": "\/original\/wp-admin\/admin-ajax.php",
        "wc_ajax_url": "\/original\/?wc-ajax=%%endpoint%%"
    };
</script>
<script type='text/javascript' id='wc-cart-fragments-js-extra'>
    var wc_cart_fragments_params = {
        "ajax_url": "\/original\/wp-admin\/admin-ajax.php",
        "wc_ajax_url": "\/original\/?wc-ajax=%%endpoint%%",
        "cart_hash_key": "wc_cart_hash_8d66c714ba0c169725b1e40aed0492fe",
        "fragment_name": "wc_fragments_8d66c714ba0c169725b1e40aed0492fe",
        "request_timeout": "5000"
    };
</script>
<script type='text/javascript' id='ghostpool-custom-js-extra'>
    var ghostpool_script = {
        "url": "https:\/\/aardvark.ghostpool.com\/original\/",
        "max_num_pages": "0",
        "get_template_directory_uri": "https:\/\/aardvark.ghostpool.com\/original\/wp-content\/themes\/aardvark",
        "bp_item_tabs_nav_text": "Navigation",
        "hide_move_primary_menu_links": "enabled",
        "scroll_to_fixed_header": "200",
        "lightbox": "group_images",
        "automatic_video_resizing": "enabled"
    };
</script>
<script type='text/javascript' id='mediaelement-core-js-before'>
    var mejsL10n = {
        "language": "en",
        "strings": {
            "mejs.download-file": "Download File",
            "mejs.install-flash": "You are using a browser that does not have Flash player enabled or installed. Please turn on your Flash player plugin or download the latest version from https:\/\/get.adobe.com\/flashplayer\/",
            "mejs.fullscreen": "Fullscreen",
            "mejs.play": "Play",
            "mejs.pause": "Pause",
            "mejs.time-slider": "Time Slider",
            "mejs.time-help-text": "Use Left\/Right Arrow keys to advance one second, Up\/Down arrows to advance ten seconds.",
            "mejs.live-broadcast": "Live Broadcast",
            "mejs.volume-help-text": "Use Up\/Down Arrow keys to increase or decrease volume.",
            "mejs.unmute": "Unmute",
            "mejs.mute": "Mute",
            "mejs.volume-slider": "Volume Slider",
            "mejs.video-player": "Video Player",
            "mejs.audio-player": "Audio Player",
            "mejs.captions-subtitles": "Captions\/Subtitles",
            "mejs.captions-chapters": "Chapters",
            "mejs.none": "None",
            "mejs.afrikaans": "Afrikaans",
            "mejs.albanian": "Albanian",
            "mejs.arabic": "Arabic",
            "mejs.belarusian": "Belarusian",
            "mejs.bulgarian": "Bulgarian",
            "mejs.catalan": "Catalan",
            "mejs.chinese": "Chinese",
            "mejs.chinese-simplified": "Chinese (Simplified)",
            "mejs.chinese-traditional": "Chinese (Traditional)",
            "mejs.croatian": "Croatian",
            "mejs.czech": "Czech",
            "mejs.danish": "Danish",
            "mejs.dutch": "Dutch",
            "mejs.english": "English",
            "mejs.estonian": "Estonian",
            "mejs.filipino": "Filipino",
            "mejs.finnish": "Finnish",
            "mejs.french": "French",
            "mejs.galician": "Galician",
            "mejs.german": "German",
            "mejs.greek": "Greek",
            "mejs.haitian-creole": "Haitian Creole",
            "mejs.hebrew": "Hebrew",
            "mejs.hindi": "Hindi",
            "mejs.hungarian": "Hungarian",
            "mejs.icelandic": "Icelandic",
            "mejs.indonesian": "Indonesian",
            "mejs.irish": "Irish",
            "mejs.italian": "Italian",
            "mejs.japanese": "Japanese",
            "mejs.korean": "Korean",
            "mejs.latvian": "Latvian",
            "mejs.lithuanian": "Lithuanian",
            "mejs.macedonian": "Macedonian",
            "mejs.malay": "Malay",
            "mejs.maltese": "Maltese",
            "mejs.norwegian": "Norwegian",
            "mejs.persian": "Persian",
            "mejs.polish": "Polish",
            "mejs.portuguese": "Portuguese",
            "mejs.romanian": "Romanian",
            "mejs.russian": "Russian",
            "mejs.serbian": "Serbian",
            "mejs.slovak": "Slovak",
            "mejs.slovenian": "Slovenian",
            "mejs.spanish": "Spanish",
            "mejs.swahili": "Swahili",
            "mejs.swedish": "Swedish",
            "mejs.tagalog": "Tagalog",
            "mejs.thai": "Thai",
            "mejs.turkish": "Turkish",
            "mejs.ukrainian": "Ukrainian",
            "mejs.vietnamese": "Vietnamese",
            "mejs.welsh": "Welsh",
            "mejs.yiddish": "Yiddish"
        }
    };
</script>

<script defer src="<?= base_url() ?>assets/js/autoptimize_55a24aed4460a128137797181fc2209e.js"></script>
<!-- Bootstrap 4 -->
<script src="<?= base_url() ?>assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- SweetAlert2 -->
<script src="<?= base_url() ?>assets/plugins/sweetalert2/sweetalert2.min.js"></script>
<!-- Toastr -->
<script src="<?= base_url() ?>assets/plugins/toastr/toastr.min.js"></script>
<script>
    $(function() {
        var Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000
        });

        $('.swalDefaultSuccess').click(function() {
            Toast.fire({
                icon: 'success',
                title: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
            })
        });
        $('.swalDefaultInfo').click(function() {
            Toast.fire({
                icon: 'info',
                title: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
            })
        });
        $('.swalDefaultError').click(function() {
            Toast.fire({
                icon: 'error',
                title: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
            })
        });
        $('.swalDefaultWarning').click(function() {
            Toast.fire({
                icon: 'warning',
                title: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
            })
        });
        $('.swalDefaultQuestion').click(function() {
            Toast.fire({
                icon: 'question',
                title: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
            })
        });

        $('.toastrDefaultSuccess').click(function() {
            toastr.success('Lorem ipsum dolor sit amet, consetetur sadipscing elitr.')
        });
        $('.toastrDefaultInfo').click(function() {
            toastr.info('Lorem ipsum dolor sit amet, consetetur sadipscing elitr.')
        });
        $('.toastrDefaultError').click(function() {
            toastr.error('Lorem ipsum dolor sit amet, consetetur sadipscing elitr.')
        });
        $('.toastrDefaultWarning').click(function() {
            toastr.warning('Lorem ipsum dolor sit amet, consetetur sadipscing elitr.')
        });

        $('.toastsDefaultDefault').click(function() {
            $(document).Toasts('create', {
                title: 'Toast Title',
                body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
            })
        });
        $('.toastsDefaultTopLeft').click(function() {
            $(document).Toasts('create', {
                title: 'Toast Title',
                position: 'topLeft',
                body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
            })
        });
        $('.toastsDefaultBottomRight').click(function() {
            $(document).Toasts('create', {
                title: 'Toast Title',
                position: 'bottomRight',
                body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
            })
        });
        $('.toastsDefaultBottomLeft').click(function() {
            $(document).Toasts('create', {
                title: 'Toast Title',
                position: 'bottomLeft',
                body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
            })
        });
        $('.toastsDefaultAutohide').click(function() {
            $(document).Toasts('create', {
                title: 'Toast Title',
                autohide: true,
                delay: 750,
                body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
            })
        });
        $('.toastsDefaultNotFixed').click(function() {
            $(document).Toasts('create', {
                title: 'Toast Title',
                fixed: false,
                body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
            })
        });
        $('.toastsDefaultFull').click(function() {
            $(document).Toasts('create', {
                body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.',
                title: 'Toast Title',
                subtitle: 'Subtitle',
                icon: 'fas fa-envelope fa-lg',
            })
        });
        $('.toastsDefaultFullImage').click(function() {
            $(document).Toasts('create', {
                body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.',
                title: 'Toast Title',
                subtitle: 'Subtitle',
                image: '../../dist/img/user3-128x128.jpg',
                imageAlt: 'User Picture',
            })
        });
        $('.toastsDefaultSuccess').click(function() {
            $(document).Toasts('create', {
                class: 'bg-success',
                title: 'Toast Title',
                subtitle: 'Subtitle',
                body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
            })
        });
        $('.toastsDefaultInfo').click(function() {
            $(document).Toasts('create', {
                class: 'bg-info',
                title: 'Toast Title',
                subtitle: 'Subtitle',
                body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
            })
        });
        $('.toastsDefaultWarning').click(function() {
            $(document).Toasts('create', {
                class: 'bg-warning',
                title: 'Toast Title',
                subtitle: 'Subtitle',
                body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
            })
        });
        $('.toastsDefaultDanger').click(function() {
            $(document).Toasts('create', {
                class: 'bg-danger',
                title: 'Toast Title',
                subtitle: 'Subtitle',
                body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
            })
        });
        $('.toastsDefaultMaroon').click(function() {
            $(document).Toasts('create', {
                class: 'bg-maroon',
                title: 'Toast Title',
                subtitle: 'Subtitle',
                body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
            })
        });
    });
</script>
</body>
<!-- Mirrored from aardvark.ghostpool.com/original/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 08 Oct 2021 12:58:59 GMT -->

</html>